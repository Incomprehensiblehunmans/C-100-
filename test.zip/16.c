# include <stdio.h>

//题目：用*号输出字母C的图案。

int main(){

    printf("*******\n");
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("*\n");
    printf("*******\n");
    return 0;
}